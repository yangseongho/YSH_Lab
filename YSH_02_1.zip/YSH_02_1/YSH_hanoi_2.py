from YSH_hanoi_1 import runtime_hanoi_tower

n = int(input("하노이 타워의 높이를 설정해주세요 :"))
runtime_hanoi_tower(n)