from YSH_MazeDFS import DFS

DFS()